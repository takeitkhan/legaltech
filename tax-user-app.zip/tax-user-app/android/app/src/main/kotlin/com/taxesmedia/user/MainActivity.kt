package com.taxesmedia.user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
