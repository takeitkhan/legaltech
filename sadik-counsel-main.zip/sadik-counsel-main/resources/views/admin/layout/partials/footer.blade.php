 <footer class="main-footer">
    <strong>Copyright &copy; {{ date('Y-m-d') }} <a href="https://sadikcounsel.com/">Sadik & Counsel</a>.</strong>
    All rights reserved
  </footer>
