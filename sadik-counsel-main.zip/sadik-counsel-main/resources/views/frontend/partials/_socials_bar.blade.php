<div class="icon-bar">
    <a href="{{ $settings['facebook_link']['value'] ?? '#' }}" class="facebook pt"><ion-icon name="logo-facebook"></ion-icon></a>
    <a href="{{ $settings['instagram_link']['value'] ?? '#' }}" class="instagram pt"><ion-icon name="logo-instagram"></ion-icon></a>
    <a href="{{ $settings['linkedin_link']['value'] ?? '#' }}" class="linkedin pt"><ion-icon name="logo-linkedin"></ion-icon></a>
    <a href="{{ $settings['twitter_link']['value'] ?? '#' }}" class="twitter pt"><ion-icon name="logo-twitter"></ion-icon></a>
</div>