export default {
  baseURL: process.env.VUE_APP_BACKEND_URL,
}
