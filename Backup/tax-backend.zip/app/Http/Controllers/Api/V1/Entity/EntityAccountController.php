<?php

namespace App\Http\Controllers\Api\V1\Entity;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class EntityAccountController extends Controller
{
    //
}
