<?php


$imagick = new Imagick()
