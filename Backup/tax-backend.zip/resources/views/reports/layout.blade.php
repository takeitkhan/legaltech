<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        *{
          margin:0;
          padding:0;box-sizing:border-box;
        }
        .user-timeline-list{
            /* border-left:1px solid */
        }
        .user-timeline-list .single-timeline .badge{
          width:20px;
          height:20px !important;
          border-radius:50% !important;

        }
        td,tr,th{
          text-align:left;
          padding:1rem !important;
        }
        .custom-control-primary{
          padding:0.5rem;
        }

        tfoot tr,tfoot tr td{
          height:20px !important;
           padding:20px 10px !important;
           background:#fff;
        }
    </style>
</head>
<body>

</body>
</html>
