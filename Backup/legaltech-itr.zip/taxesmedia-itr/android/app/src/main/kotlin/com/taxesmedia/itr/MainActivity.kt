package com.taxesmedia.itr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
