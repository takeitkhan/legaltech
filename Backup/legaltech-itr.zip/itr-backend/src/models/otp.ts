import {model, Schema} from 'mongoose';

interface IOTP {
  phone: string;
  code: number;
  createdAt: Date;
}

const OTPSchema = new Schema<IOTP>(
  {
    phone: {
      type: String,
      required: true,
    },
    code: {
      type: Number,
      required: true,
    },
    createdAt: {
      type: Date,
      expires: '1h',
      default: Date.now,
    },
  },
);

export default model<IOTP>('OTP', OTPSchema);
