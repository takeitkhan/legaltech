import jwt from 'jsonwebtoken';
import {model, Schema} from 'mongoose';
import config from '../config';

export interface IUser {
  name?: string;
  phone: string;
  nid: string;
  tin: string;
  occupation: string;
}

interface IUserInstanceMethods {
  generateAuthToken: () => string;
}

const schema = new Schema<IUser & IUserInstanceMethods>({
  name: {
    type: String,
    trim: true,
  },
  phone: {
    type: String,
    required: true,
    trim: true,
  },
  nid: {
    type: String,
    required: true,
    trim: true,
  },
  tin: {
    type: String,
    required: true,
    trim: true,
  },
  occupation: {
    type: String,
    trim: true,
  },
}, {
  timestamps: true,
});

schema.methods.generateAuthToken = function() {
  return jwt.sign({_id: this._id}, config.authSecret, {expiresIn: '30d'},
  );
};

export default model<IUser & IUserInstanceMethods>('User', schema);
