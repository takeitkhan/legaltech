import OTP from '../models/otp';
import User, {IUser} from '../models/user';


export default class AuthService {
  // Send OTP
  async sendOTP(phone: string) {
    try {
      await OTP.findOneAndDelete({phone});
      await OTP.create({
        phone,
        code: 1234,
      });
      return true;
    } catch (error) {
      return error as Error;
    }
  }

  // Verify OTP
  async verifyOTP(phone: string, code: number) {
    try {
      const otp = await OTP.findOneAndDelete({phone, code});
      if (!otp) return new Error('Invalid OTP');
      const user = await User.findOne({phone});
      if (!user) return {verified: true, isRegistered: false};
      const token = user.generateAuthToken();
      return {user, token};
    } catch (error) {
      return error as Error;
    }
  }

  // Register
  async register(userData: IUser) {
    try {
      const user = await User.findOne({
        $or: [
          {phone: userData.phone},
          {nid: userData.nid},
          {tin: userData.tin},
        ],
      });
      if (user?.phone == userData.phone) {
        return Error('Phone number is already registered');
      }
      if (user?.nid == userData.nid) {
        return Error('NID number is already registered');
      }
      if (user?.tin == userData.tin) {
        return Error('TIN is already registered');
      }
      const newUser = await User.create(userData);
      const token = newUser.generateAuthToken();
      return {newUser, token};
    } catch (error) {
      return error as Error;
    }
  }
}
