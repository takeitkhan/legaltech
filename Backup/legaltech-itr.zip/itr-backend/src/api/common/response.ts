import {Response} from 'express';
import Logger from '../../loaders/logger';

export interface ISuccessData {
  res: Response;
  message: string;
  data?: object;
  statusCode?: number;
}

export function successRes(response: ISuccessData): Response {
  return response.res.status(response.statusCode ?? 200).json({
    message: response.message,
    data: response.data,
  });
}

export function errorRes(
  res: Response, error: Error, statusCode = 500,
): Response {
  if (error.name == 'Error') {
    return res.status(statusCode).json({
      error: {message: error.message},
    });
  }
  Logger.error(error);
  return res.status(statusCode).json({error: error});
}
