import {Request} from 'express';
import Joi from 'joi';

export default {
  validateSendOTP(req: Request) {
    const schema = Joi.object({
      phone: Joi.string().required(),
    });
    return schema.validate({phone: req.body.phone}).error;
  },

  validateVerifyOTP(req: Request) {
    const schema = Joi.object({
      phone: Joi.string().required(),
      otp: Joi.number().required(),
    });
    return schema.validate({
      phone: req.body.phone,
      otp: req.body.otp,
    }).error;
  },

  validateRegister(req: Request) {
    const schema = Joi.object({
      phone: Joi.string().required(),
      nid: Joi.string().required(),
      tin: Joi.string().required(),
    });
    return schema.validate({
      phone: req.body.phone,
      nid: req.body.nid,
      tin: req.body.tin,
    }).error;
  },
};
