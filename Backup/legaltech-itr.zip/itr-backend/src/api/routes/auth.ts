import {Router} from 'express';
import AuthService from '../../services/auth';
import {errorRes, ISuccessData, successRes} from '../common/response';
import authValidator from '../validators/auth';

const router = Router();

export default (app: Router) => {
  app.use('/auth', router);
  const authService = new AuthService();

  router.post('/send-otp', async (req, res) => {
    const error = authValidator.validateSendOTP(req);
    if (error) return errorRes(res, new Error(error?.message), 400);
    const result = await authService.sendOTP(req.body.phone);
    if (result instanceof Error) return errorRes(res, result);
    return successRes({res, message: 'OTP successfully sent'});
  });

  router.post('/verify-otp', async (req, res) => {
    const error = authValidator.validateVerifyOTP(req);
    if (error) return errorRes(res, new Error(error?.message), 400);
    const result = await authService.verifyOTP(req.body.phone, req.body.otp);
    if (result instanceof Error) return errorRes(res, result);
    const response: ISuccessData = {res, message: 'Successfully verified'};
    if (result.token && result.user) {
      res.setHeader('access-token', result.token);
      response.data = result.user;
    }
    return successRes(response);
  });

  router.post('/register', async (req, res) => {
    const error = authValidator.validateRegister(req);
    if (error) return errorRes(res, new Error(error?.message), 400);
    const result = await authService.register(req.body);
    if (result instanceof Error) return errorRes(res, result);
    res.setHeader('access-token', result.token);
    return successRes({
      res,
      message: 'Registration successful',
      data: result.newUser,
      statusCode: 201,
    });
  });

  return app;
};
